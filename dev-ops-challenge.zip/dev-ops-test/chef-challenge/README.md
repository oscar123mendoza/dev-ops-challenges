# chef-challenge

## Documentation

## Bonus Question Answers (Optional)

1. How would you ensure that a new application server is discovered by the load balancer without any explicit definitions for it in the load balancer recipe(s)?
1. How would you extract environment-specific configuration to allow the same set of recipes to be applied across a multi-stage deployment environment?
