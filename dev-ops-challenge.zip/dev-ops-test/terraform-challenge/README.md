# terraform-challenge

## Documentation

## Bonus Question Answers (Optional)

1. How would you expand the architecture to work across multiple availability zones?
1. How would you set up a replicated database?
